<html><head></head><body>
<?php 
		$query_total = $this->db->query("SELECT * from tb_penyaluran where kdpenyaluran='$kode'");
		foreach ($query_total->result_array() as $t) :
			$idkegiatan= $t['idkegiatan'];
			$nmpenerima = $t['nmpenerima'];
			$idlvl5 = $t['idlvl5'];
			$jabatan = $t['jabatan'];
			$alamat = $t['alamat'];
			$tanggal = $t['tgltransaksi'];
			$nominal = $t['nompenyaluran'];
			$nmpenyaluran = $t['nmpenyaluran'];
			$ketua =$t['ketua'];
			$bendahara =$t['bendahara'];
			
			$image= $t['image'];
		//cek program
		$query_rkakl = $this->db->query("SELECT tb_grandp.kdgrandp, tb_program.kdprogram,tb_subprogram.kdsubp,tb_komponen.kdkomp,tb_kegiatan.kdkegiatan,tb_kegiatan.nmkegiatan FROM tb_grandp,tb_program,tb_subprogram,tb_komponen,tb_kegiatan WHERE tb_kegiatan.idkomp=tb_komponen.idkomp and tb_komponen.idsubp = tb_subprogram.idsubp and tb_subprogram.idprogram=tb_program.idprogram and tb_program.idgrandp=tb_grandp.idgrandp and tb_kegiatan.idkegiatan='$idkegiatan' ");
       	foreach ($query_rkakl->result_array() as $a) :
		$kdgrandp= $a['kdgrandp'];
		$kdprogram= $a['kdprogram'];
		$kdsubp= $a['kdsubp'];
		$kdkomp= $a['kdkomp'];
		$kdkegiatan= $a['kdkegiatan'];
		$nmkegiatan = $a['nmkegiatan'];
		//cek akun
		$query_akun = $this->db->query("SELECT * from tb_lvl5 where idlvl5='$idlvl5'");
		foreach ($query_akun->result_array() as $b) :
		$kdakun5=$b['kdakun5'];
		$nmakun5=$b['nmakun5'];

?>
<p><img src="<?php echo base_url() . 'theme/images/kwitansi/logo.png' ?>">
</p>
<p>Sudah terima dari Badan Amil Zakat Nasional Kabupaten Tangerang :</p>
<table width="624" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>Kode Program</td>
    <td>:</td>
    <td><?= "$kdgrandp.$kdprogram.$kdsubp.$kdkomp.$kdkegiatan"; ?></td>
  </tr>
  <tr>
    <td>Kegiatan</td>
    <td>:</td>
    <td><?= "$nmkegiatan"; ?> </td>
  </tr>
  <tr>
    <td>Akun</td>
    <td>:</td>
    <td><?= "$kdakun5.$nmakun5 "; ?></td>
  </tr>
  <tr>
    <td>Nomor Kwitansi </td>
    <td>:</td>
    <td><?= "$kode "; ?> </td>
  </tr>
  <tr>
    <td width="107">Terbilang</td>
    <td width="10">:</td>
    <td width="445"># <?php function penyebut($nilai)
					{
						$nilai = abs($nilai);
						$huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
						$temp = "";
						if ($nilai < 12) {
							$temp = " " . $huruf[$nilai];
						} else if ($nilai < 20) {
							$temp = penyebut($nilai - 10) . " belas";
						} else if ($nilai < 100) {
							$temp = penyebut($nilai / 10) . " puluh" . penyebut($nilai % 10);
						} else if ($nilai < 200) {
							$temp = " seratus" . penyebut($nilai - 100);
						} else if ($nilai < 1000) {
							$temp = penyebut($nilai / 100) . " ratus" . penyebut($nilai % 100);
						} else if ($nilai < 2000) {
							$temp = " seribu" . penyebut($nilai - 1000);
						} else if ($nilai < 1000000) {
							$temp = penyebut($nilai / 1000) . " ribu" . penyebut($nilai % 1000);
						} else if ($nilai < 1000000000) {
							$temp = penyebut($nilai / 1000000) . " juta" . penyebut($nilai % 1000000);
						} else if ($nilai < 1000000000000) {
							$temp = penyebut($nilai / 1000000000) . " milyar" . penyebut(fmod($nilai, 1000000000));
						} else if ($nilai < 1000000000000000) {
							$temp = penyebut($nilai / 1000000000000) . " trilyun" . penyebut(fmod($nilai, 1000000000000));
						}
						return $temp;
					}

					function terbilang($nilai)
					{
						if ($nilai < 0) {
							$hasil = "minus " . trim(penyebut($nilai));
						} else {
							$hasil = trim(penyebut($nilai));
						}
						return $hasil;
					}


					// $angka = 1530093;
					echo terbilang($nominal);
					?> rupiah # </td>
  </tr>
  <tr>
    <td>Nominal </td>
    <td>:</td>
    <td><?php echo 'Rp ' . number_format($nominal); ?></td>
  </tr>
  <tr>
    <td>Untuk</td>
    <td>:</td>
    <td><?= " $nmpenyaluran "; ?></td>
  </tr>
  <tr>
    <td>Nama Penerima </td>
    <td>:</td>
    <td><?= " $nmpenerima "; ?></td>
  </tr>
  <tr>
    <td>Jabatan</td>
    <td>:</td>
    <td><?= " $jabatan "; ?></td>
  </tr>
  <tr>
    <td>Alamat</td>
    <td>:</td>
    <td><?= " $alamat "; ?></td>
  </tr>
</table>

<table width="626" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="136"><div align="center">Disetujui</div></td>
    <td width="177"><div align="center">Dibayar</div></td>
    <td width="309"><div align="center">Tangerang, <?php
	
	function tgl_indo($tanggala){
	$bulan = array (
		1 =>   'Januari',
		'Februari',
		'Maret',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Agustus',
		'September',
		'Oktober',
		'November',
		'Desember'
	);
	$pecahkan = explode('-', $tanggala);
	
	// variabel pecahkan 0 = tanggal
	// variabel pecahkan 1 = bulan
	// variabel pecahkan 2 = tahun
 
	return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
	
	// $tgl = date('d m Y', strtotime($tanggal));
	echo tgl_indo($tanggal);?></div></td>
  </tr>
  <tr>
    <td><div align="center">Ketua</div></td>
    <td><div align="center">Bendahara</div></td>
    <td><div align="center">Yang Menerima </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">
        <?= " $ketua "; ?>
    </div></td>
    <td><div align="center">
        <?= " $bendahara "; ?>
    </div></td>
    <td><div align="center">
        <?= " $nmpenerima "; ?>
    </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><img style="width: 100px;" src="<?php echo base_url().'assets/images/'.$image;?>"></div></td>
    <td><div align="center"></div></td>
    <td><div align="center"></div></td>
  </tr>
</table>
<p></p>
<?php endforeach; ?>
<?php endforeach; ?>
<?php endforeach; ?>
</body></html>

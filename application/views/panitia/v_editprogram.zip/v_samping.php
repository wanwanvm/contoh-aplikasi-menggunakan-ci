<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar Menu -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header"> TAHUN ANGGARAN <?php $tahun = $this->session->userdata('tahun'); ?><?php echo "$tahun"; ?></li>
      <!-- Optionally, you can add icons to the links -->

      <li class="active"><a href="#"><i class="fa fa-cogs"></i> <span>Modul Pengaturan</span></a></li>

      <li class="treeview">
        <a href="#"><i class="fa fa-archive"></i> <span>Modul Pengangaran</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url() . 'panitia/grandp' ?>"><i class="fa fa-chevron-right"></i>Grand Program</a></li>
          <li><a href="<?php echo base_url() . 'panitia/program' ?>"><i class="fa fa-chevron-right"></i>Program</a></li>
          <li><a href="<?php echo base_url() . 'panitia/subprogram' ?>"><i class="fa fa-chevron-right"></i>Sub Program</a></li>
          <li><a href="<?php echo base_url() . 'panitia/komponen' ?>"><i class="fa fa-chevron-right"></i>Komponen</a></li>
          <li><a href="<?php echo base_url() . 'panitia/kegiatan' ?>"><i class="fa fa-chevron-right"></i>Kegiatan</a></li>
          <li><a href="<?php echo base_url() . 'panitia/rkakl' ?>"><i class="fa fa-chevron-right"></i>Rkakl</a></li>

        </ul>
      </li>


      <li class="treeview">
        <a href="#"><i class="fa fa-sitemap"></i> <span>Modul Akun</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url() . 'panitia/akunlvl1' ?>"><i class="fa fa-chevron-right"></i>Akun Level 1</a></li>
          <li><a href="<?php echo base_url() . 'panitia/akunlvl2' ?>"><i class="fa fa-chevron-right"></i>Akun Level 2</a></li>
          <li><a href="<?php echo base_url() . 'panitia/akunlvl3' ?>"><i class="fa fa-chevron-right"></i>Akun Level 3</a></li>
          <li><a href="<?php echo base_url() . 'panitia/akunlvl4' ?>"><i class="fa fa-chevron-right"></i>Akun Level 4</a></li>
          <li><a href="<?php echo base_url() . 'panitia/akunlvl5' ?>"><i class="fa fa-chevron-right"></i>Akun Level 5</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#"><i class="fa fa-credit-card"></i> <span>Modul Penerimaan</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url() . 'panitia/Saldodana' ?>"><i class="fa fa-chevron-right"></i>Saldo Dana</a></li>
          <li><a href="<?php echo base_url() . 'panitia/penerimaan' ?>"><i class="fa fa-chevron-right"></i>Penerimaan</a></li>
         
        </ul>
      </li>
      <li class="treeview">
        <a href="#"><i class="fa fa-child"></i> <span>Modul Pengeluaran</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url() . 'panitia/kewajiban' ?>"><i class="fa fa-chevron-right"></i>Kewajiban</a></li>
          <li><a href="<?php echo base_url() . 'panitia/penyaluran' ?>"><i class="fa fa-chevron-right"></i>Penyaluran Dana</a></li>
        </ul>
      </li>
	    <li class="treeview">
        <a href="#"><i class="fa fa-area-chart"></i> <span>Modul Pelaporan</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="#"><i class="fa fa-chevron-right"></i>Kas Bantu</a></li>
          <li><a href="#"><i class="fa fa-chevron-right"></i>Kas Penerimaan</a></li>
		  <li><a href="#"><i class="fa fa-chevron-right"></i>Realisasi Anggaran</a></li>
        </ul>
      </li>
     

      <li><a href="<?php echo base_url() . 'panitia/login/logout' ?>"><i class="fa fa-sign-out"></i> <span>Keluar</span></a></li>
    </ul>
    <!-- /.sidebar-menu -->
  </section>
  <!-- /.sidebar -->
</aside>